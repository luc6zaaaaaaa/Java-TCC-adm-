package io.helidon.hol.lc4j.ai;

import io.helidon.integrations.langchain4j.Ai;
import dev.langchain4j.service.SystemMessage;

@Ai.Service
@Ai.ChatMemoryWindow(10)
public interface ChatAiService {

    @SystemMessage("""
            Você é Frank - um assistente amigável de um cabeleireiro.
            Você deve responder apenas a perguntas relacionadas aos serviços de cabeleireiro e agendamentos.
            """)
    String chat(String question);
    
    default String handleQuestion(String question) {
        if (question.contains("serviços")) {
            return "Oferecemos cortes de cabelo, coloração, e tratamentos capilares.";
        } else if (question.contains("agendar")) {
            return "Você pode agendar um horário pelo nosso site ou ligando para nós.";
        } else if (!isRelevantQuestion(question)) {
            return "Desculpe, mas não posso ajudar com isso. Posso responder perguntas sobre nossos serviços.";
        }
        return callAiModel(question); // Chamar o modelo de IA para outras perguntas
    }

    private boolean isRelevantQuestion(String question) {
        return question.contains("cabelo") || question.contains("serviço") || question.contains("agendar");
    }
}