package io.helidon.hol.lc4j;

import io.helidon.common.config.Config;
import io.helidon.hol.lc4j.ai.MenuItemsIngestor;
import io.helidon.hol.lc4j.rest.ChatBotService;
import io.helidon.logging.common.LogConfig;
import io.helidon.service.registry.Services;
import io.helidon.webserver.WebServer;

public class ApplicationMain {
    public static void main(String[] args) {
        // Configura o logging
        LogConfig.configureRuntime();

        // Carrega as configurações
        var config = Config.create();

        // Inicializa o ingestor de itens do menu
        try {
            Services.get(MenuItemsIngestor.class).ingest();
        } catch (Exception e) {
            System.err.println("Erro ao inicializar o ingestor: " + e.getMessage());
            System.exit(1);
        }

        // Inicia o servidor web
        WebServer.builder()
                .config(config.get("server"))
                .routing(routing -> routing.register("/", Services.get(ChatBotService.class)))
                .build()
                .start();

        System.out.println("Servidor iniciado na porta " + config.get("server.port").asInt().orElse(8080));
    }
}