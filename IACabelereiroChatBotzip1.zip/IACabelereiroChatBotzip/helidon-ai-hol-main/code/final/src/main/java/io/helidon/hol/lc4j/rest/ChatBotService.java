package io.helidon.hol.lc4j.rest;

import io.helidon.hol.lc4j.ai.ChatAiService;
import io.helidon.hol.lc4j.data.MenuItemsService;
import io.helidon.hol.lc4j.data.MenuItem;
import io.helidon.service.registry.Service;
import io.helidon.webserver.http.HttpRules;
import io.helidon.webserver.http.HttpService;
import io.helidon.webserver.http.ServerRequest;
import io.helidon.webserver.http.ServerResponse;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

@Service.Singleton
public class ChatBotService implements HttpService {

    private final ChatAiService chatAiService;
    private final Map<String, String> clientData = new HashMap<>();
    private final Map<String, Double> services = new HashMap<>();
    private final String[] workingDays = {"Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"};
    private final String openingHour = "09:00";
    private final String closingHour = "20:00";
    private final Map<String, List<String>> bookedSlots = new HashMap<>();
    private final MenuItemsService menuItemsService = new MenuItemsService();

    public ChatBotService(ChatAiService chatAiService) {
        this.chatAiService = chatAiService;
        addService("Corte", 30.0);
        addService("Pezinho", 15.0);
    }

    @Override
    public void routing(HttpRules httpRules) {
        httpRules.get("/chat", this::chatWithAssistant);
    }

    private void chatWithAssistant(ServerRequest req, ServerResponse res) {
        var clientId = req.query().first("clientId").orElse("unknown");
        var question = req.query().first("question").orElse("Hello");

        if (!clientData.containsKey(clientId)) {
            clientData.put(clientId, question);
            res.send("Qual é o seu nome?");
        } else {
            String clientName = clientData.get(clientId);
            res.send("Olá " + clientName + ", quais serviços você gostaria de agendar? " + listServices());
            // Aqui você pode adicionar lógica para perguntar sobre o dia
        }
    }

    public void addService(String name, double price) {
        services.put(name, price);
    }

    private String listServices() {
        StringBuilder serviceList = new StringBuilder("Serviços disponíveis:\n");
        services.forEach((service, price) -> serviceList.append(service).append(" - R$").append(price).append("\n"));
        return serviceList.toString();
    }

    public void askForDay(String clientId) {
        // Pergunta ao cliente qual dia deseja agendar
        System.out.println("Qual dia você gostaria de agendar? (Ex: Segunda)");
    }

    public void showAvailableSlots(String day, ServerResponse res) {
        List<String> slots = bookedSlots.getOrDefault(day, new ArrayList<>());
        List<String> availableSlots = new ArrayList<>();

        // Gera horários disponíveis
        for (int hour = 9; hour < 20; hour++) {
            for (int minute = 0; minute < 60; minute += 30) {
                String time = String.format("%02d:%02d", hour, minute);
                if (!slots.contains(time)) {
                    availableSlots.add(time);
                }
            }
        }

        if (availableSlots.isEmpty()) {
            res.send("Não há horários disponíveis neste dia.");
        } else {
            res.send("Horários disponíveis para " + day + ": " + String.join(", ", availableSlots));
        }
    }

    public void scheduleService(String clientId, String serviceName, String day, String time) {
        if (!services.containsKey(serviceName)) {
            System.out.println("Serviço não encontrado.");
            return;
        }

        if (!bookedSlots.containsKey(day)) {
            bookedSlots.put(day, new ArrayList<>());
        }

        List<String> slots = bookedSlots.get(day);
        if (slots.contains(time)) {
            System.out.println("Horário já ocupado. Escolha outro horário.");
        } else {
            slots.add(time);
            saveBooking(clientId, serviceName, day, time);
            System.out.println("Agendamento realizado com sucesso!");
        }
    }

    private void saveBooking(String clientId, String serviceName, String day, String time) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("agendamentos.txt", true))) {
            writer.write("Cliente: " + clientId + ", Serviço: " + serviceName + ", Dia: " + day + ", Horário: " + time);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Erro ao salvar o agendamento: " + e.getMessage());
        }
    }

    // Método para listar serviços do MenuItemsService
    private String listMenuServices() {
        StringBuilder serviceList = new StringBuilder("Serviços disponíveis:\n");
        for (MenuItem item : menuItemsService.getMenuItems()) {
            serviceList.append(item.getName())
                       .append(" - R$")
                       .append(item.getPrice())
                       .append(" (Duração: ")
                       .append(item.getDuration())
                       .append(" minutos)\n")
                       .append("Descrição: ")
                       .append(item.getDescription())
                       .append("\n");
        }
        return serviceList.toString();
    }
}