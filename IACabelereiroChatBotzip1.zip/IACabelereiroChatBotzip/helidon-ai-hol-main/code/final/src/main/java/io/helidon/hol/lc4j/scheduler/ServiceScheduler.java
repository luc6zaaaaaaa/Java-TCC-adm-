package io.helidon.hol.lc4j.scheduler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class ServiceScheduler {
    private final Map<String, LocalDateTime> scheduledServices; // Armazena serviços agendados

    public ServiceScheduler() {
        this.scheduledServices = new HashMap<>();
    }

    public boolean scheduleService(String userId, LocalDateTime dateTime) {
        // Verifica se o horário está disponível
        if (isAvailable(dateTime)) {
            scheduledServices.put(userId, dateTime);
            return true; // Serviço agendado com sucesso
        }
        return false; // Horário não disponível
    }

    public boolean cancelService(String userId) {
        return scheduledServices.remove(userId) != null; // Remove o serviço agendado
    }

    public boolean isAvailable(LocalDateTime dateTime) {
        // Verifica se o horário está livre
        return !scheduledServices.containsValue(dateTime);
    }

    public Map<String, LocalDateTime> getScheduledServices() {
        return new HashMap<>(scheduledServices); // Retorna uma cópia dos serviços agendados
    }
}