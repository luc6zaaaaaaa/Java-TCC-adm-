package io.helidon.hol.lc4j.data;

public class MenuItem {
    private String name; // Nome do serviço
    private String description; // Descrição do serviço
    private double price; // Preço do serviço
    private int duration; // Duração do serviço em minutos

    // Construtor
    public MenuItem(String name, String description, double price, int duration) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.duration = duration;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public int getDuration() {
        return duration;
    }
}