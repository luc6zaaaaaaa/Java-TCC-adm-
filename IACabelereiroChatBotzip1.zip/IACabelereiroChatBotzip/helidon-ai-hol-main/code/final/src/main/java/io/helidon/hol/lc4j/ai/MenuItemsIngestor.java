package io.helidon.hol.lc4j.ai;

import java.util.logging.Logger;

import io.helidon.common.config.Config;
import io.helidon.hol.lc4j.data.MenuItem;
import io.helidon.hol.lc4j.data.MenuItemsService;
import io.helidon.service.registry.Service;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.store.embedding.EmbeddingStore;
import dev.langchain4j.store.embedding.EmbeddingStoreIngestor;

@Service.Singleton
public class MenuItemsIngestor {
    private static final Logger LOGGER = Logger.getLogger(MenuItemsIngestor.class.getName());

    private final EmbeddingStore<TextSegment> embeddingStore;
    private final EmbeddingModel embeddingModel;
    private final MenuItemsService menuItemsService;

    @Service.Inject
    public MenuItemsIngestor(Config config,
                             EmbeddingStore<TextSegment> embeddingStore,
                             EmbeddingModel embeddingModel,
                             MenuItemsService menuItemsService) {
        this.embeddingStore = embeddingStore;
        this.embeddingModel = embeddingModel;
        this.menuItemsService = menuItemsService;
    }

    public void ingest() {
        // Cria o ingestor com o modelo de embedding e o armazenamento
        var ingestor = EmbeddingStoreIngestor.builder()
                .embeddingModel(embeddingModel)
                .embeddingStore(embeddingStore)
                .build();

        try {
            // Lê os itens do menu do serviço
            var menuItems = menuItemsService.getMenuItems();
            LOGGER.info("Iniciando a ingestão de " + menuItems.size() + " itens do menu.");

            // Cria representações de texto dos itens do menu
            var documents = menuItems.stream()
                    .filter(this::isValidMenuItem) // Filtra itens inválidos
                    .map(this::generateDocument)
                    .toList();

            // Alimenta o ingestor para criar embeddings e armazená-los
            ingestor.ingest(documents);
            LOGGER.info("Ingestão concluída com sucesso.");
        } catch (Exception e) {
            LOGGER.severe("Erro ao ingerir itens do menu: " + e.getMessage());
        }
    }

    private boolean isValidMenuItem(MenuItem item) {
        // Valida se o item do menu possui todos os campos necessários
        return item.getName() != null && !item.getName().isEmpty() &&
               item.getPrice() > 0 &&
               item.getDescription() != null && !item.getDescription().isEmpty();
    }

    private Document generateDocument(MenuItem item) {
        // Gera uma representação textual do item do menu
        var str = String.format(
                "%s: %s. Categoria: %s. Preço: R$%.2f. Tags: %s. Adicionais: %s.",
                item.getName(),
                item.getDescription(),
                item.getCategory(),
                item.getPrice(),
                String.join(", ", item.getTags()),
                String.join(", ", item.getAddOns())
        );

        return Document.from(str);
    }
}