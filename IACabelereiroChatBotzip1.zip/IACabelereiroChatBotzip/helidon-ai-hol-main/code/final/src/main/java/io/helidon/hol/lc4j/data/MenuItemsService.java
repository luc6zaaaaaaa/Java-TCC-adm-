package io.helidon.hol.lc4j.data;

import java.util.ArrayList;
import java.util.List;

public class MenuItemsService {
    private List<MenuItem> menuItems;

    public MenuItemsService() {
        this.menuItems = new ArrayList<>();
        // Adiciona serviços iniciais
        addMenuItem(new MenuItem("Corte", "Corte de cabelo", 30.0, 30));
        addMenuItem(new MenuItem("Pezinho", "Acabamento do pezinho de cabelo: limpeza e definição da linha do cabelo na região do pescoço, garantindo um acabamento impecável e bem cuidado.", 15.0, 15)); // Atualização da descrição
    }

    public void addMenuItem(MenuItem item) {
        menuItems.add(item);
    }

    public List<MenuItem> getMenuItems() {
        return menuItems;
    }
}