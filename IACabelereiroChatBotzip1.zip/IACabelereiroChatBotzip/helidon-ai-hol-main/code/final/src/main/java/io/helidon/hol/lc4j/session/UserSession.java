package io.helidon.hol.lc4j.rest;

import io.helidon.hol.lc4j.session.UserSession;
import io.helidon.webserver.http.HttpRules;
import io.helidon.webserver.http.HttpService;
import io.helidon.webserver.http.ServerRequest;
import io.helidon.webserver.http.ServerResponse;

@Service.Singleton
public class ChatBotService implements HttpService {

    @Override
    public void routing(HttpRules httpRules) {
        httpRules.get("/chat", this::chatWithAssistant);
    }

    private void chatWithAssistant(ServerRequest req, ServerResponse res) {
        String userId = req.query().first("userId").orElse("defaultUser ");
        UserSession session = getSessionForUser (userId); // Método para obter ou criar a sessão do usuário

        var question = req.query().first("question").orElse("Hello");
        session.setLastQuestion(question);

        // Lógica para gerar resposta do assistente
        String answer = generateResponse(question);
        session.setLastResponse(answer);

        res.send(answer);
    }

    private UserSession getSessionForUser (String userId) {
        // Lógica para obter ou criar uma nova UserSession
        return new UserSession(userId);
    }

    private String generateResponse(String question) {
        // Lógica para gerar a resposta com base na pergunta
        return "Resposta gerada para: " + question;
    }
}